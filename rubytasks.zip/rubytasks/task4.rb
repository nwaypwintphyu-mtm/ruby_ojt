puts "Enter array size :"
array_size = gets.chomp().to_i-1
count =0;
animals = Array(array_size)
i= 1
for i in 0..array_size.to_i
    puts "Enter animal name : "
    animal = gets.chomp()
        animals[i] = animal
        count += 1
        puts count.to_s + " times."
end
puts "The sorted array " + animals.sort.to_s
puts "No duplicated array " + animals.uniq.to_s
puts "The reverse array " + animals.reverse.to_s
