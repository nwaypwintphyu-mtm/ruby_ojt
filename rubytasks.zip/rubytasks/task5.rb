require 'date'
a = Date.today.strftime("%A")
puts "Today is "+a +"."
a1 = Date.today.prev_day.strftime("%A")
a2 = Date.today.prev_day.prev_day.strftime("%A")
a3 = Date.today.prev_day.prev_day.prev_day.strftime("%A")
a4 = Date.today.prev_day.prev_day.prev_day.prev_day.strftime("%A")
a5 = Date.today.prev_day.prev_day.prev_day.prev_day.prev_day.strftime("%A")
puts "Last 5 days are "+ a1 +" , "+ a2 +" , "+ a3 +" , "+ a4 +" , "+a5+"."