
userchoice = "y";
while userchoice=="y"
    puts "Enter first number :"
    num1 = gets.chomp().to_i;
    puts "Choose operator (+ , - , * , /) :"
    operator = gets.chomp();
    puts "Enter second number :"
    num2 = gets.chomp().to_i;
    
    case operator
    when "+"
        result =  num1+num2
    when "-"
        result =  num1-num2
    when "*"
        result =  num1*num2
    when "+"
        result =  num1/num2
    end
    puts ("The result is " + result.to_s)
    puts "Want to continue or stop (y/n) :"
    userchoice = gets.chomp();
end
puts "process stop"
