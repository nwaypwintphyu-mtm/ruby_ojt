class Person
    attr_accessor :name 
    def initialize(name)
        @name = name
    end
    def print_name()
        puts name
    end
end

class Student < Person
    attr_accessor :rollno 
    def initialize(name,rollno)
        @rollno = rollno
        @name = name
    end
    def print_roll()
        puts rollno
    end
end

puts "Choose Person or Studen (p/s) :"
choice = gets.chomp();
if choice == "p"
    puts "Enter name :"
    name = gets.chomp()
    p1 = Person.new(name)
    p1.print_name
elsif choice == "s"
    puts "Enter name :"
    name = gets.chomp()
    puts "Enter roll :"
    roll = gets.chomp()
    s1 = Student.new(name,roll)
    s1.print_name
    s1.print_roll
end




