count = 1
space = 0
max = 12
min = 1
while count<max do
        space = ' '* (max-count/2)
        puts (space+'*'*count +space)
   
    count +=2
end
while count>=min do
    space = ' '* (max-count/2)
    puts (space+'*'*count +space)
count -=2
end
