now = Time.now.strftime("%Y")
puts "Enter your birth year : "
byear = gets.chomp()
age = (now.to_i - byear.to_i)
if age<19
    puts "18,child"
else
    puts "19,adult"
end

