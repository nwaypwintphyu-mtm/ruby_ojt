puts "Enter title : "
title = gets.chomp()

puts "Enter notes : "
notes = gets.chomp()

puts "Do you want to save (y/n) :"
save = gets.chomp()

if save == "y"
    File.open("task6notes.txt","a") do |file|
        file.write("\n" + title +"\n" +notes)
    end
    
    begin
        File.open("task6notes.txt", "r") do |file|
            for line in file.readlines()
                puts line
            end
        end
    rescue 
        puts "File not found !"
    end
else
end
